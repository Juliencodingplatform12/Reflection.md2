let mouseXRandom, mouseYRandom;


function setup() {
  createCanvas(600, 600);
  background('black')
  color = (0, 255)
  x = (0, 600)
  y = (0, 600)
}

function draw() {
  background(220);
  circle(random(x), random(y), random(color))
 
  mouseXRandom = mouseX + random(-50, 50);
  mouseYRandom = mouseY + random(-50, 50);
 
  fill(random(color), random(color), random(color));
  ellipse(mouseXRandom, mouseYRandom, 30, 30)
 

}